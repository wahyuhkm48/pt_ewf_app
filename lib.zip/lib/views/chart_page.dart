// views/chart_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/empty_state.dart';
import '../widgets/tradingview_chart.dart';
import '../viewmodels/histori_viewmodel.dart';
import '../models/histori_data_model.dart';
import '../utils/histori_excel_exporter.dart';

class ChartPage extends StatefulWidget {
  const ChartPage({super.key});

  @override
  State<ChartPage> createState() => _ChartPageState();
}

class _ChartPageState extends State<ChartPage> {
  int _selectedTab = 0; // 0 = Gold, 1 = JPK, 2 = HKK
  final List<String> _tabs = const ['Gold', 'JPK', 'HKK'];
  final List<String> _tvSymbols = const ['Saxo:XAUUSD', 'Vantage:NIKKEI225', 'IG:HANGSENG'];
  bool _isExporting = false;
  int _chartVersion = 0; // dinaikkan setiap refresh -> key berubah -> TradingView dimuat ulang

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HistoriViewModel>().loadTab(_selectedTab);
    });
  }

  void _pindahTab(int index) {
    setState(() => _selectedTab = index);
    context.read<HistoriViewModel>().loadTab(index);
  }

  /// Muat ulang chart TradingView + tabel data historis untuk tab yang sedang aktif.
  Future<void> _refresh() async {
    final vm = context.read<HistoriViewModel>();
    setState(() => _chartVersion++);
    await vm.loadTab(_selectedTab, forceRefresh: true);
  }

  Future<void> _unduhExcel() async {
    if (_isExporting) return;

    final data = context.read<HistoriViewModel>().forTab(_selectedTab);
    final messenger = ScaffoldMessenger.of(context);

    if (data.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Belum ada data untuk diunduh')),
      );
      return;
    }

    setState(() => _isExporting = true);
    try {
      await HistoriExcelExporter.export(namaProduk: _tabs[_selectedTab], data: data);
    } catch (_) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Gagal membuat file Excel, coba lagi')),
      );
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<HistoriViewModel>();

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _refresh,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Chart', style: AppTextStyles.h1()),
              const SizedBox(height: 16),
              _buildTabs(),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                height: 400,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.divider)),
                child: TradingViewChart(
                  key: ValueKey('${_tvSymbols[_selectedTab]}#$_chartVersion'),
                  symbol: _tvSymbols[_selectedTab],
                  interval: 'D',
                  height: 400,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Data Historis', style: AppTextStyles.h3()),
                  Material(
                    color: AppColors.successBg,
                    borderRadius: BorderRadius.circular(10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: _isExporting ? null : _unduhExcel,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _isExporting
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.success),
                                  )
                                : const Icon(Icons.file_download_outlined, size: 16, color: AppColors.success),
                            const SizedBox(width: 6),
                            Text(
                              _isExporting ? 'Menyiapkan...' : 'Excel',
                              style: AppTextStyles.labelMd(color: AppColors.success),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                decoration: BoxDecoration(border: Border.all(color: AppColors.divider), borderRadius: BorderRadius.circular(14)),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                      decoration: const BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(14), topRight: Radius.circular(14)),
                      ),
                      child: Row(
                        children: [
                          _dateCell('TANGGAL', AppTextStyles.labelSm()),
                          _ohlcCell('OPEN', AppTextStyles.labelSm()),
                          _ohlcCell('HIGH', AppTextStyles.labelSm()),
                          _ohlcCell('LOW', AppTextStyles.labelSm()),
                          _ohlcCell('CLOSE', AppTextStyles.labelSm()),
                        ],
                      ),
                    ),
                    Builder(builder: (context) {
                      if (vm.isLoading && !vm.hasData(_selectedTab)) {
                        return const Padding(padding: EdgeInsets.symmetric(vertical: 28), child: Center(child: CircularProgressIndicator()));
                      }
                      if (vm.errorMessage != null && !vm.hasData(_selectedTab)) {
                        return GestureDetector(
                          onTap: () => context.read<HistoriViewModel>().loadTab(_selectedTab, forceRefresh: true),
                          child: const EmptyState(
                            icon: Icons.error_outline_rounded,
                            iconSize: 30,
                            title: 'Gagal memuat data (tap untuk coba lagi)',
                            padding: EdgeInsets.symmetric(vertical: 28),
                          ),
                        );
                      }
                      final data = vm.forTab(_selectedTab);
                      if (data.isEmpty) {
                        return const EmptyState(
                          icon: Icons.table_chart_outlined,
                          iconSize: 30,
                          title: 'Belum ada data historis',
                          padding: EdgeInsets.symmetric(vertical: 28),
                        );
                      }
                      return Column(children: data.map((d) => _HistoryRow(data: d)).toList());
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(30)),
      child: Row(
        children: List.generate(_tabs.length, (index) {
          final selected = _selectedTab == index;
          return Expanded(
            child: GestureDetector(
              onTap: () => _pindahTab(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: selected ? AppColors.primary : Colors.transparent, borderRadius: BorderRadius.circular(26)),
                alignment: Alignment.center,
                child: Text(_tabs[index],
                    style: AppTextStyles.labelMd(color: selected ? Colors.white : AppColors.textSecondary)),
              ),
            ),
          );
        }),
      ),
    );
  }
}

// Lebar kolom tanggal. Kecilkan angka ini kalau mau OHLC lebih dekat ke tanggal.
const double _kDateColWidth = 78;

Widget _dateCell(String text, TextStyle style) => SizedBox(
      width: _kDateColWidth,
      child: FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Text(text, maxLines: 1, style: style),
      ),
    );

// Sel OHLC. Besarkan `horizontal` kalau mau jarak antar OHLC lebih lebar.
Widget _ohlcCell(String text, TextStyle style) => Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(text, maxLines: 1, style: style),
        ),
      ),
    );

class _HistoryRow extends StatelessWidget {
  final HistoriDataModel data;
  const _HistoryRow({required this.data});

  String _formatDate(DateTime date) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    final style = AppTextStyles.caption(color: AppColors.textPrimary);

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.divider, width: 0.5))),
      child: Row(
        children: [
          _dateCell(_formatDate(data.tanggal), style),
          _ohlcCell(data.open.toStringAsFixed(2), style),
          _ohlcCell(data.high.toStringAsFixed(2), style),
          _ohlcCell(data.low.toStringAsFixed(2), style),
          _ohlcCell(data.close.toStringAsFixed(2), style),
        ],
      ),
    );
  }
}