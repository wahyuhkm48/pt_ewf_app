// views/pivot_point_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/pivot_point_viewmodel.dart';

class PivotPointPage extends StatefulWidget {
  const PivotPointPage({super.key});
  @override
  State<PivotPointPage> createState() => _PivotPointPageState();
}

class _PivotPointPageState extends State<PivotPointPage> {
  final highCtrl = TextEditingController();
  final lowCtrl = TextEditingController();
  final closeCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<PivotPointViewModel>();

    return Scaffold(
      appBar: AppBar(title: const Text('Kalkulator Pivot Point')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: highCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'High')),
            TextField(controller: lowCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Low')),
            TextField(controller: closeCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Close')),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => vm.hitung(
                double.parse(highCtrl.text),
                double.parse(lowCtrl.text),
                double.parse(closeCtrl.text),
              ),
              child: const Text('Hitung'),
            ),
            const SizedBox(height: 16),
            if (vm.isLoading) const CircularProgressIndicator(),
            if (vm.result != null) ...[
              Text('Pivot Point: ${vm.result!.pivotPoint}'),
              Text('Resistance: ${vm.result!.resistance}'),
              Text('Support: ${vm.result!.support}'),
            ],
          ],
        ),
      ),
    );
  }
}