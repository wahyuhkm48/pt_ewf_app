// models/pivot_point_model.dart
class PivotPointModel {
  final int id;
  final double pivotPoint;
  final List<double> resistance;
  final List<double> support;
  final List<Map<String, dynamic>>? chartPoints;
  final DateTime? tanggal;

  PivotPointModel({
    required this.id,
    required this.pivotPoint,
    required this.resistance,
    required this.support,
    this.chartPoints,
    this.tanggal,
  });

  factory PivotPointModel.fromJson(Map<String, dynamic> json) => PivotPointModel(
        id: json['id'],
        pivotPoint: (json['pivot_point'] as num).toDouble(),
        resistance: (json['resistance'] as List).map((e) => (e as num).toDouble()).toList(),
        support: (json['support'] as List).map((e) => (e as num).toDouble()).toList(),
        chartPoints: json['chart_points'] != null
            ? List<Map<String, dynamic>>.from(json['chart_points'])
            : null,
        tanggal: json['tanggal'] != null ? DateTime.tryParse(json['tanggal']) : null,
      );
}