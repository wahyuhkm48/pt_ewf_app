import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../models/news_article.dart';

class NewsService {
  static const String _baseUrl = 'https://newsdata.io/api/1/latest';

  Future<List<NewsArticle>> fetchNews({
    required String query,
    String language = 'en',
    String category = 'business',
  }) async {
    final apiKey = dotenv.env['NEWSDATA_API_KEY'];
    if (apiKey == null || apiKey.isEmpty) {
      debugPrint('❌ NEWSDATA_API_KEY tidak ditemukan di .env');
      throw Exception('NEWSDATA_API_KEY tidak ditemukan di file .env');
    }
    debugPrint('🔑 API key ditemukan, panjang: ${apiKey.length} karakter');

    final uri = Uri.parse(
      '$_baseUrl?apikey=$apiKey&q=${Uri.encodeComponent(query)}&language=$language&category=$category',
    );

    debugPrint('📡 Request URL: $uri');

    final response = await http.get(uri);

    debugPrint('📡 Status code: ${response.statusCode}');
    debugPrint('📡 Response body: ${response.body}');

    if (response.statusCode != 200) {
      throw Exception('Gagal mengambil berita (status: ${response.statusCode}, body: ${response.body})');
    }

    final Map<String, dynamic> data = jsonDecode(response.body);

    if (data['status'] != 'success') {
      throw Exception('API mengembalikan status gagal: ${data['results']?['message'] ?? data['message'] ?? data}');
    }

    final List<dynamic> results = data['results'] ?? [];
    return results.map((item) => NewsArticle.fromJson(item)).toList();
  }
}