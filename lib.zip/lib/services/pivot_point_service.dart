// services/pivot_point_service.dart
import '../core/api_client.dart';
import '../models/pivot_point_model.dart';

class PivotPointService {
  final ApiClient _client;
  PivotPointService(this._client);

  Future<PivotPointModel> hitung(double high, double low, double close) async {
    final res = await _client.post('/pivot-point/hitung', {
      'harga_high': high,
      'harga_low': low,
      'harga_close': close,
    });
    return PivotPointModel.fromJson(res['data'] ?? res);
  }

  Future<List<PivotPointModel>> riwayat() async {
    final res = await _client.get('/pivot-point');
    final list = (res['data'] ?? res) as List;
    return list.map<PivotPointModel>((e) => PivotPointModel.fromJson(e)).toList();
  }
}